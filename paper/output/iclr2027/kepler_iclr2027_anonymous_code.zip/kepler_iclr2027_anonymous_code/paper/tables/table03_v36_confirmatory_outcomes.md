# v3.6 confirmatory onset outcomes

Prospectively frozen outcomes across eight paired blocks. Each block crosses one held-out rule, cue permutation, and initialization; trajectories are paired observations, not independent inference units.

| Version | Status | Condition | n | Onset by 5M | Onset by 10M | Onset exposures (M) | Terminal ordinals | Established by 5M | Established by 10M | Mean R, 5M pre | Mean R, 10M |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| v3.6 | confirmatory | R0 | 8 | 0 | 1 | —, —, 7.5, —, —, —, —, — | 8, 8, 6, 8, 8, 8, 8, 8 | 0 | 2 | 1.000239 | 0.432743 |
| v3.6 | confirmatory | R1 | 8 | 5 | 6 | 4, 4, 5, 4, 7.5, —, —, 4 | 3, 3, 4, 3, 6, 8, 8, 3 | 4 | 6 | 0.303076 | 0.110766 |
| v3.6 | confirmatory | R2 | 8 | 8 | 8 | 3, 3, 4, 4, 4, 3, 4, 4 | 2, 2, 3, 3, 3, 2, 3, 3 | 6 | 8 | 0.04371 | 0.005181 |
