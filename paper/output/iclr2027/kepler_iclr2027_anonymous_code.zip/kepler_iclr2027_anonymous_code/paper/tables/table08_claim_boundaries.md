# Claim-boundary table

The manuscript uses the allowed scoped statements and excludes the listed overclaims.

| Topic | Allowed statement | Excluded statement |
| --- | --- | --- |
| Causal scope | The registered transient cue-bearing full-support distributions changed onset timing or probability in the frozen parent-exposed task and model family. | Singleton mutual information alone is the causal variable. |
| Persistence | Threshold-positive representations persisted after return to uniform full support. | The cue is permanently required for prediction. |
| Generality | The ordered effect replicated across the two new rules and two new permutations tested. | This is a universal Transformer property. |
| Dynamics | The registered checkpoints show abrupt or delayed representation formation in some trajectories. | The result is a thermodynamic phase transition. |
| Recurrent task | The parent-exposed task isolates a mechanism relevant to the broader program. | The recurrent production task has been solved. |
| Scaling | The experiments are mechanism-focused exploratory and confirmatory audits. | The result belongs in the original scaling fit. |
| C_single | C_single is a registered scalar cue index used to order selected distributions. | C_single is a unique-information percentage. |
