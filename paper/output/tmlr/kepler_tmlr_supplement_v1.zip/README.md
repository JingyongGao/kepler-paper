# Anonymous lightweight reproduction package

This package contains the frozen result tables, manifests, distribution
audits, figure/table source data, deterministic builders, and a lightweight
verification path. It contains no model checkpoints and performs no optimizer
steps.

The machine-readable result copies differ from the frozen source bytes only
where absolute local filesystem paths were replaced by relative paths for
double-blind review. `SOURCE_ARTIFACT_HASHES.json` records the original frozen
SHA-256 values, packaged SHA-256 values, and every sanitized JSON field.
Scientific numbers, conditions, coding, and statistical definitions are
unchanged.

## Install

```sh
uv sync --frozen
```

## Verify package hashes

```sh
uv run python paper/scripts/verify_tmlr_supplement.py
```

## Recompute distribution invariants, transition coding, and the exact test

```sh
uv run --frozen python paper/scripts/verify_results.py
```

## Rebuild every publication figure and table from packaged JSON

```sh
uv run --frozen --with reportlab==4.4.9 python paper/scripts/build_figures.py
uv run --frozen python paper/scripts/build_tables.py
```

All commands above are read-only with respect to model parameters and perform
zero training or optimizer steps.
